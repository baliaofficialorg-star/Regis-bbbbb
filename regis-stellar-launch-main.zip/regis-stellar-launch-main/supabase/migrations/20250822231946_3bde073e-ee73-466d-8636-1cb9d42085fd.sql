-- Create table to track faucet claims
CREATE TABLE public.faucet_claims (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  wallet_address TEXT NOT NULL,
  claimed_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  amount DECIMAL(18,6) NOT NULL DEFAULT 0.1,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable Row Level Security
ALTER TABLE public.faucet_claims ENABLE ROW LEVEL SECURITY;

-- Create policies for faucet claims (public read, restricted write)
CREATE POLICY "Anyone can view faucet claims" 
ON public.faucet_claims 
FOR SELECT 
USING (true);

-- Create index for better performance on wallet lookups
CREATE INDEX idx_faucet_claims_wallet_date ON public.faucet_claims(wallet_address, claimed_at DESC);
CREATE INDEX idx_faucet_claims_date ON public.faucet_claims(claimed_at DESC);