-- Remove the existing public read policy that exposes all wallet addresses
DROP POLICY IF EXISTS "Anyone can view faucet claims" ON public.faucet_claims;

-- Create a new policy that only allows the service role to read/write
-- This allows the faucet edge function to work while protecting user data
CREATE POLICY "Only service role can access faucet claims" 
ON public.faucet_claims 
FOR ALL 
TO service_role 
USING (true) 
WITH CHECK (true);

-- Optional: Allow users to view only their own claims if they're authenticated
-- and provide their wallet address (this would require frontend changes)
CREATE POLICY "Users can view their own wallet claims" 
ON public.faucet_claims 
FOR SELECT 
TO authenticated 
USING (false); -- Disabled for now since we don't have wallet-to-user mapping